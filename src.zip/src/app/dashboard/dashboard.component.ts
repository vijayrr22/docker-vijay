import { Component, OnInit } from '@angular/core';
import { ResponsiveService } from '../shared/responsive/responsive.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss',
  standalone: false
})
export class DashboardComponent implements OnInit {

  /** Static component data */
  dashboard_data: any = [
    { navigation_code: 'code1', navigation_name: 'Dashboard Card 1', link: '#' },
    { navigation_code: 'code2', navigation_name: 'Dashboard Card 2', link: '#' },
    { navigation_code: 'code3', navigation_name: 'Dashboard Card 3', link: '#' }
  ];
  user_name: string = 'User Name';  // Static User Name
  role_name: string = 'User Role';  // Static Role Name
  notification_available: boolean = false;
  notification_visible: boolean = true;

  constructor() {
  }

  ngOnInit() {
    // Static Initialization (no API calls)
    this.dashboard_data = [
      { navigation_code: 'code1', navigation_name: 'Card 1', link: '#' },
      { navigation_code: 'code2', navigation_name: 'Card 2', link: '#' }
    ];
  }

  // No API calls, so we don't need to worry about fetching user data

  logout() {
    // No functionality for logout
    console.log('Logout clicked');
  }

  notificationOpen() {
    // No functionality for notification
    console.log('Notification clicked');
  }
  getStarted(){
    console.log("Clicked Get Started");

  }
}