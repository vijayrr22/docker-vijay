export let navigation_codes:any ={
    'home':1001,

  }