import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import * as component from './costa/costa.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { navigation_codes } from './core/enum';


const routes: Routes = [
  {
    path: '',
    component: component.CostaComponent,
    children: [
      {
        path: '',
        component: DashboardComponent,
      },
      {
        path: 'home',
        loadChildren: () => import('./modules/home.module').then(m => m.HomeModule),
        data: {
          navigationCode: navigation_codes['home']
        }
      }
    ],

  }
];

// need to add LazyLoading

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }