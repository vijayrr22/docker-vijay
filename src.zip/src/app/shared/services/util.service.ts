import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Injectable({
  providedIn: 'root'
})
export class UtilService {

  constructor(private translateService: TranslateService) { }

    /**
* param translated value 
*            
* Do the translation based on the selected language.
*/
  languageTranslator(key: any, topicName?: any): string {
    let translatedvalue: any;
    this.translateService.get(key, { value: topicName }).subscribe(value => {
      translatedvalue = value;
    });
    return translatedvalue;
  }
}
