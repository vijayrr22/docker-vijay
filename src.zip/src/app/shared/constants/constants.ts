export const navigation = {
    error: "/",
    dashboard: '/',
}