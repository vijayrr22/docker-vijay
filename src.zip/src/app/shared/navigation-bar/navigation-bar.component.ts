import { Component } from '@angular/core';
import { Router } from '@angular/router';
import * as constant from './../../shared/constants/constants';

@Component({
  selector: 'app-navigation-bar',
  templateUrl: './navigation-bar.component.html',
  styleUrl: './navigation-bar.component.scss',
  standalone: false
})
export class NavigationBarComponent {
  menu_data:any = [];
  user_name: string = "Test";
  role_name: string = "Admin";
  navigation_open: boolean = false;

  constructor(
    private router: Router,
  ){

  }
  checkSideBarVisiblity(){
    if(this.router.url == constant.navigation.dashboard){
      return false;
    }
    return true;
  }
  tooltipShow() {
    console.log("Before", this.navigation_open);
    document.body.classList.toggle('tooltipShow', !this.navigation_open);
    console.log("After", this.navigation_open);
  }
}
