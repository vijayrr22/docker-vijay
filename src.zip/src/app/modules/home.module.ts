import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { HomeLandingComponent } from '../home-landing/home-landing.component';


const routes: Routes = [
  { path: '', pathMatch: 'full', component: HomeLandingComponent, data: { title: 'Home Landing' } },
]
@NgModule({
  declarations: [
    HomeLandingComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
  ]
})
export class HomeModule { }
