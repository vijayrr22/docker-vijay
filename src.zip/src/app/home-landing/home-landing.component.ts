import { Component } from '@angular/core';

@Component({
  selector: 'app-home-landing',
  templateUrl: './home-landing.component.html',
  styleUrl: './home-landing.component.scss',
  standalone : false
})
export class HomeLandingComponent {

}
