import { Component } from '@angular/core';

@Component({
  selector: 'app-costa',
  templateUrl: './costa.component.html',
  styleUrl: './costa.component.scss',
  standalone: false
})
export class CostaComponent {
  show_navbar: boolean = false;
  constructor(){
    this.show_navbar=true;
  }
}
