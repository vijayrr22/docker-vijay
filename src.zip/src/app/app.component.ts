import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ResponsiveService } from 'src/app/shared/responsive/responsive.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  standalone: false,
})
export class AppComponent {

  constructor(public responsiveService:ResponsiveService, public translate : TranslateService) {
    console.log(responsiveService);
    translate.use('en')
  }
  title = 'costa-coffee-ui';
}
